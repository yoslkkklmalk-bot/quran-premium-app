const DEMO = {
  dataset:{counts:{surahs:1,ayahs:7,pages:1}},
  surahs:[{number:1,name_arabic:"الفاتحة",name_transliteration:"Al-Fatihah",revelation:{type:"مكية"},ayahs:[
    {number:1,verse_key:"1:1",text:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",page:1,juz:1},
    {number:2,verse_key:"1:2",text:"الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",page:1,juz:1},
    {number:3,verse_key:"1:3",text:"الرَّحْمَٰنِ الرَّحِيمِ",page:1,juz:1},
    {number:4,verse_key:"1:4",text:"مَالِكِ يَوْمِ الدِّينِ",page:1,juz:1},
    {number:5,verse_key:"1:5",text:"إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",page:1,juz:1},
    {number:6,verse_key:"1:6",text:"اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",page:1,juz:1},
    {number:7,verse_key:"1:7",text:"صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",page:1,juz:1}
  ]}]
};

const SURAHS = ["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];

const state = {
  data:null, page:Number(localStorage.getItem("quran:lastPage")||1),
  fontSize:Number(localStorage.getItem("quran:fontSize")||22),
  font:"Amiri", dark:localStorage.getItem("quran:dark")==="1",
  highlight:localStorage.getItem("quran:highlight")!=="0"
};

const $=s=>document.querySelector(s);
const arabicDigits=n=>String(n).replace(/\d/g,d=>"٠١٢٣٤٥٦٧٨٩"[d]);
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),1800)}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function markAllah(s){
  let safe=escapeHtml(s);
  if(!state.highlight)return safe;
  const re=/(?:ٱ|ا|ل)?ل{2}(?:ّ|ْ|ٰ|َ|ِ|ُ|ً|ٍ|ٌ)*ه(?:ُ|َ|ِ|ْ|ً|ٍ|ٌ|ٰ)*/g;
  return safe.replace(re,m=>`<span class="allah">${m}</span>`);
}
function allAyahs(){return state.data.surahs.flatMap(s=>s.ayahs.map(a=>({...a,surah:s})))}
function pageAyahs(page){return allAyahs().filter(a=>Number(a.page)===page)}
function renderPage(){
  const ayahs=pageAyahs(state.page);
  const mushaf=$("#mushaf");
  if(!ayahs.length){
    mushaf.innerHTML=`<div class="surah-header">الصفحة ${arabicDigits(state.page)}</div><p style="text-align:center;color:var(--muted)">لا توجد بيانات لهذه الصفحة في النسخة الحالية.</p>`;
  }else{
    let html="", lastSurah=0;
    ayahs.forEach(a=>{
      if(a.surah.number!==lastSurah){
        lastSurah=a.surah.number;
        html+=`<div class="surah-header">سورة ${escapeHtml(a.surah.name_arabic)}</div>`;
        if(a.surah.number!==9 && a.number===1) html+=`<div class="basmala">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>`;
      }
      html+=`<p class="ayah-line">${markAllah(a.text)} <span class="ayah-number">${arabicDigits(a.number)}</span></p>`;
    });
    mushaf.innerHTML=html;
  }
  $("#pageNow").textContent=arabicDigits(state.page);
  $("#continuePage").textContent=`الصفحة ${arabicDigits(state.page)}`;
  const first=ayahs[0];
  $("#surahLabel").textContent=first?`سورة ${first.surah.name_arabic}`:"القرآن الكريم";
  $("#juzLabel").textContent=first?`الجزء ${arabicDigits(first.juz||1)}`:"";
  document.documentElement.style.setProperty("--qsize",state.fontSize+"px");
  $("#fontSizeLabel").textContent=arabicDigits(state.fontSize);
  $("#setFontSize").textContent=arabicDigits(state.fontSize);
  localStorage.setItem("quran:lastPage",state.page);
  $("#prevBtn").disabled=state.page<=1; $("#nextBtn").disabled=state.page>=604;
}
async function loadData(){
  // Priority: bundled local data/quran.json -> IndexedDB cache -> remote source -> demo.
  try{
    const r=await fetch("data/quran.json",{cache:"no-store"});
    if(r.ok){state.data=await r.json(); return "local";}
  }catch(e){}
  try{
    const cached=await idbGet();
    if(cached){state.data=cached; return "cache";}
  }catch(e){}
  try{
    const urls = [
      "https://raw.githubusercontent.com/mjmirza/quran-dataset/main/data/quran.json",
      "https://raw.githubusercontent.com/Mushaf-Learning/quran-text/main/data/quran.json"
    ];
    for (const url of urls) {
      try {
        const r = await fetch(url, {cache:"force-cache"});
        if (!r.ok) continue;
        const json = await r.json();
        if (json && Array.isArray(json.surahs) && json.surahs.length === 114) {
          state.data = json;
          await idbSet(state.data);
          return "online";
        }
      } catch (_) {}
    }
    throw Error("No Quran dataset source available");
  }catch(e){
    state.data=DEMO; return "demo";
  }
}
function idbOpen(){
  return new Promise((res,rej)=>{const r=indexedDB.open("quran-premium",1);r.onupgradeneeded=()=>r.result.createObjectStore("store");r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})
}
async function idbSet(data){const db=await idbOpen();return new Promise((res,rej)=>{const tx=db.transaction("store","readwrite");tx.objectStore("store").put(data,"quran");tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function idbGet(){const db=await idbOpen();return new Promise((res,rej)=>{const tx=db.transaction("store");const r=tx.objectStore("store").get("quran");r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}

function buildSurahList(){
  const list=$("#surahList");
  const surahs=state.data.surahs;
  list.innerHTML=surahs.map((s,i)=>`<button class="surah-item" data-surah="${s.number}"><span><b>${escapeHtml(s.name_arabic)}</b><small>${s.revelation?.type||""} • ${arabicDigits(s.ayahs.length)} آيات</small></span><span class="surah-num">${arabicDigits(s.number)}</span></button>`).join("");
  list.querySelectorAll("[data-surah]").forEach(b=>b.onclick=()=>{
    const s=state.data.surahs.find(x=>x.number==b.dataset.surah); const a=s?.ayahs?.[0]; if(a?.page){state.page=Number(a.page);renderPage();closeDrawer()}
  });
}
function openSearch(){ $("#searchModal").classList.add("open"); $("#modalSearch").focus() }
function doSearch(q){
  q=q.trim();
  if(!q){$("#searchResults").innerHTML="";return}
  const nq=q.replace(/\s+/g," ").toLowerCase();
  const hits=allAyahs().filter(a=>a.text.toLowerCase().includes(nq)).slice(0,60);
  $("#searchResults").innerHTML=hits.length?hits.map(a=>`<button class="result" data-page="${a.page}"><b>سورة ${escapeHtml(a.surah.name_arabic)} • آية ${arabicDigits(a.number)} • صفحة ${arabicDigits(a.page)}</b><p>${markAllah(a.text)}</p></button>`).join(""):`<div class="result">لا توجد نتائج.</div>`;
  $("#searchResults").querySelectorAll("[data-page]").forEach(x=>x.onclick=()=>{state.page=Number(x.dataset.page);renderPage();$("#searchModal").classList.remove("open")});
}
function applyPrefs(){
  document.body.classList.toggle("dark",state.dark);
  document.documentElement.style.setProperty("--font",state.font==="Noto"?'"Noto Naskh Arabic",serif':state.font==="serif"?"serif":'"Amiri",serif');
  $("#darkToggle").checked=state.dark; $("#allahToggle").checked=state.highlight; $("#fontSelect").value=state.font;
}
function savePrefs(){localStorage.setItem("quran:dark",state.dark?"1":"0");localStorage.setItem("quran:highlight",state.highlight?"1":"0");localStorage.setItem("quran:fontSize",state.fontSize);localStorage.setItem("quran:font",state.font)}
function closeDrawer(){$("#drawer").classList.remove("open")}
function setup(){
  state.font=localStorage.getItem("quran:font")||"Amiri"; applyPrefs();
  $("#prevBtn").onclick=()=>{if(state.page>1){state.page--;renderPage()}};
  $("#nextBtn").onclick=()=>{if(state.page<604){state.page++;renderPage()}};
  $("#fontDown").onclick=$("#setDown").onclick=()=>{state.fontSize=Math.max(16,state.fontSize-1);savePrefs();renderPage()};
  $("#fontUp").onclick=$("#setUp").onclick=()=>{state.fontSize=Math.min(36,state.fontSize+1);savePrefs();renderPage()};
  $("#nightBtn").onclick=()=>{state.dark=!state.dark;savePrefs();applyPrefs()};
  $("#darkToggle").onchange=e=>{state.dark=e.target.checked;savePrefs();applyPrefs()};
  $("#allahToggle").onchange=e=>{state.highlight=e.target.checked;savePrefs();renderPage()};
  $("#fontSelect").onchange=e=>{state.font=e.target.value;savePrefs();applyPrefs()};
  $("#settingsBtn").onclick=()=>$("#settingsModal").classList.add("open");
  $("#bookmarkBtn").onclick=()=>{localStorage.setItem("quran:lastPage",state.page);toast(`تم حفظ الصفحة ${arabicDigits(state.page)}`)};
  $("#continueBtn").onclick=()=>{window.scrollTo({top:document.querySelector(".reader-wrap").offsetTop-80,behavior:"smooth"})};
  $("#surahBtn").onclick=()=>$("#drawer").classList.add("open"); $("#menuBtn").onclick=()=>$("#drawer").classList.add("open"); $("#drawerClose").onclick=closeDrawer;
  $("#searchInput").onfocus=openSearch; $("#searchInput").oninput=e=>{openSearch();$("#modalSearch").value=e.target.value;doSearch(e.target.value)};
  $("#modalSearch").oninput=e=>doSearch(e.target.value);
  document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$("#"+b.dataset.close).classList.remove("open"));
  document.querySelectorAll(".feature-card").forEach(b=>b.onclick=()=>{const a=b.dataset.action;if(a==="search")openSearch();if(a==="fonts")$("#settingsModal").classList.add("open");if(a==="night"){state.dark=!state.dark;savePrefs();applyPrefs()}if(a==="save"){$("#bookmarkBtn").click()}});
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.onclick=()=>{const t=b.dataset.tab;if(t==="surahs")$("#drawer").classList.add("open");else if(t==="search")openSearch();else if(t==="settings")$("#settingsModal").classList.add("open");else window.scrollTo({top:0,behavior:"smooth"})});
  $("#searchModal").addEventListener("click",e=>{if(e.target.id==="searchModal")e.currentTarget.classList.remove("open")});
  $("#settingsModal").addEventListener("click",e=>{if(e.target.id==="settingsModal")e.currentTarget.classList.remove("open")});
}
(async()=>{
  setup();
  const mode=await loadData();
  buildSurahList(); renderPage();
  if(mode==="demo") toast("وضع تجريبي: أضف data/quran.json لتشغيل المصحف كاملًا دون إنترنت.");
  if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
})();
