# NOTICE — Quran text attribution

This app is designed to bundle/cache a complete 604-page Madinah Mushaf dataset.
The default data source configured in `app.js` is `mjmirza/quran-dataset`.

Dataset facts: 114 surahs, 6,236 ayahs, 30 juz, 604 Mushaf pages.
License of the dataset project: CC BY 4.0.
The underlying Quran text/metadata source is attributed to Tanzil.net under CC BY 3.0.

If redistributing the app with the dataset bundled, keep this notice and the upstream attribution required by the dataset license.
